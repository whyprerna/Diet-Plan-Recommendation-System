from django.apps import AppConfig


class RecommenderConfig(AppConfig):
    name = 'recommender'
