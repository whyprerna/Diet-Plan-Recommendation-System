from django.apps import AppConfig


class FoodApiConfig(AppConfig):
    name = 'food_api'
