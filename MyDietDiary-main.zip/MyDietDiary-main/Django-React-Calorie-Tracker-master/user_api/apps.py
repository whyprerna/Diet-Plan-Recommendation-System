from django.apps import AppConfig


class UserApiConfig(AppConfig):
    name = 'user_api'
